# Mina's drive-project
File storage &amp; sharing system (like google drive) built with Django (python).
#### Sharing with other people 
share files and folders with other people with easy steps.
#### Modern material design
Easily manage files with better and simple ui.

## Setup
### install Django
``` pip install Django ```

You need to install following libraries to make project work properly.

#### 1. pymysql
``` pip install pymysql ```


Replace ```__init__.py``` file with uploaded ```pymysql\__init__.py``` file.(You can find new __init__.py file in pymysql folder)

#### 2.smtplib

#### 3.hashlib

#### 4.zipfile

### Database setup

Import given ```pydrive_db.sql``` file in PhPMyAdmin.(MySql Database)

Now setup is completed.

